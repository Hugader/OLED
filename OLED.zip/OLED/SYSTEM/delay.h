#ifndef __DELAY_H
#define __DELAY_H

#include "stm32f10x.h"                  // Device header

#define SYSTEM_SUPPORT_OS 0

void Delay_Init(void);
void delay_us(u32 nus);
void delay_ms(u16 nms);




#endif
