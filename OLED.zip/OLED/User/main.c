#include "delay.h"
#include "sys.h"
#include "oled.h"


/*
	@author           Hu Yinghua
	@version          V1.0
	@function name    OLED
	@description      
	@param
	@return
*/



/**
  * 坐标轴定义：
  * 左上角为(0, 0)点
  * 横向向右为X轴，取值范围：0~127
  * 纵向向下为Y轴，取值范围：0~63
  * 
  *       0             X轴           127 
  *      .------------------------------->
  *    0 |
  *      |
  *      |
  *      |
  *  Y轴 |
  *      |
  *      |
  *      |
  *   63 |
  *      v
  * 
  */




int main()
{	
	
	OLED_Init();
	Delay_Init();
	
	OLED_ShowString(16, 0, "Hello World!", OLED_8X16);
	
	
	/*调用OLED_Update函数，将OLED显存数组的内容更新到OLED硬件进行显示*/
	OLED_Update();
	
	/*延时3000ms，观察现象*/
	delay_ms(3000);
	
	
	while(1)
	{

	}
}

